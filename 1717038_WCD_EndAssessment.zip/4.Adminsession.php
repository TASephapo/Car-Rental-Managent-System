<?php

  $connection=mysqli_connect('localhost','root','','Nkhere_dba');
  
  if($connection->connect_error)
	{
		die ('failed to connect'.$connection->connect_error);
	}
 ?> 
 
 <html>
 <head><title>ADMIN </title>
 <link rel="stylesheet" type="text/css" href="5.Adminsessioncss.css">
 </head>
  <body style="background-color:#003b3b;" >
  
  
   <form action="" method="POST">
	
	<h1 align="center">ADMIN LOGIN ONLY </h1>
	 <table align="center">
		
		<tr>
			<td><input type="text" name="email" Placeholder="kakapa.khauta@gmail.com" required="required"></td></tr>
			<tr>
				<td><input type="password" name="Password4" Placeholder="Password" required="required"></td></tr>
				<tr><td><input type="submit" name="Submit" value="Sign in"></td></tr>
				

				
				
		</table>
		</form>
		
		
		<?php
		session_start();
		
	if(isset($_POST["Submit"]))
	{
		$email=$_POST['email'];
        $Password=$_POST['Password4'];
		$query=("select * from Admin where email='$email' && Password4='$Password'");
		$query=mysqli_query($connection,$query);
		$login=mysqli_num_rows($query);
		
		
		if ($login == 1)
		{
			//starting a session
			$_session['email']=$email;
			
           header("location:9.1AdminOptions.html");
		   echo '<script language="javascript">';
	       echo 'alert("successfully logged in")';
           echo'</script>';

		
		 }
		
		
		else
		{
		 echo '<script language="javascript">';
	     echo 'alert("failed to log in please try again ")';
         echo'</script>';
			
			
		}
	
	}
	
	?>
	
	</html>   
	