<?php
  if( isset ($_REQUEST) && !empty($_REQUEST))
  {
	  if (isset ($_REQUEST['phone'] , $_REQUEST['Carrier'],$_REQUEST['message'])&&
	  !empty($_REQUEST['phone']) && 
	  !empty($_REQUEST['Carrier'])
	  )
	  {
		   
		  $messege = wordwrap($_REQUEST['message'], 70);
		  $TO =$_REQUEST['phone']. '@'. $_REQUEST['Carrier'];
		  $result =@mail($TO, '', $message);
		  print 'text was sent to'. $TO;
	  }else
	  {
		  print 'information is not submitted.';
  
	  }
	  
  }
  ?>
	 