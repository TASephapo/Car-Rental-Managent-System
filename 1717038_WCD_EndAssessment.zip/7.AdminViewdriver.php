<html>
   <head><title>SELECTING FROM DRIVER </title>
   
      <style type="text/css">
   
   body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.option{
  overflow: hidden;
  background-color: transparent;
}

.option a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;

}
  ul li:hover ul li {
	  display:block;

	  }
	 body {
	
	background-image:url("yes2.jpg");
	background-repeat:none;
	background-size:cover;
	}



.option a.hover {
  background-color: gray;
  color: white;
   
}
.option a:hover {
  background-color: grey;
  color: red;
 
}
</style>
   
   
   
   
   
   </head>
    
	 <div align="center">
    <h1> DRIVERS DETAILS </h1> 
	 <table border="2" width="100">
	 <tr>
	 <th> Name </th>
	 <th>Email address </th>
	 <th>Car Registration number </th>
	 <th>License </th>
	 <th> Picture </th>
	 <th>Reviews</th>
	  <th>Ratings</th>
	  <th>Password</th>
	 
	 </tr>
	 
	 <?php
	 
	
     mysql_connect('localhost','root','') or die ('connection failed');
     mysql_select_db('Nkhere_dba') or die ('database is not selected');
	$run=mysql_query(" select * from driver");
	
	
	while( $row=(mysql_fetch_array($run)))
	{
	$name=$row[0];
	$Email=$row[1];
	$Registrationnumber=$row[2];
	$DriverLicense=$row[3];
	$Picture=$row[4];
	$Reviews=$row[5];
	$Ratings=$row[6];
	$Password=$row[7];

	
	
		
		
		echo "<tr> 
		        <td>$name </td>
				<td>$Email</td>
				<td>$Registrationnumber</td> 
				<td>$DriverLicense</td>
				<td> <img src='$Picture' height=100 width=100> </td>
				<td> $Reviews </td>
				<td> $Ratings </td>
				<td> $Password</td>
				
				</tr>";
				
	}
?>
</table>
</div>
<body>
 <div class="option">
  <a href="ClientOptions.html"><font color="white"><strong> Back page </strong></font></a>
  </div>
</body>
</html>
