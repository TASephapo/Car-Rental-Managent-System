<html>
     

  <div align="center">
        <h1> CLIENT DETAILS </h1>
		<table border="1" width="200">
		<tr>
			<th>Email </th>
			<th>Phone </th>
			<th>Password</th>
			<th>Confirm</th>
		</tr>
		

<?php
     
	 
	mysql_connect('localhost','root','') or die ('connection failed');
    mysql_select_db('Nkhere_dba') or die ('database is not selected');
    $run=mysql_query("select * from client");
    
	
 
   while( $row=(mysql_fetch_array($run)))
   {
	   
	   
	$email=$row[0];
	$phone=$row[1];
	$password=$row[2];
	$Confirm=$row[3];
    
	echo "<tr>
	          <td>$email</td>
			  <td>$phone </td>
			  <td>$password </td>
			  <td>$Confirm </td>
			 
			 </tr>";
	   
	   
  }
	   
?>
</table>
</div>
<body>
 <div class="option">
  <a href="9.1AdminOptions.html"><font color="white"><strong> Back page </strong></font></a>
  </div>
</body>
 
</html>
	
	
	
	 
	  