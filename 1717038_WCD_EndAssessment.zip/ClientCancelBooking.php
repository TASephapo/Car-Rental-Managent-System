<html>
	<head><title> CLIENT CANCEL BOOKINGS </title>
	 <style type="text/css">
   
   body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.option{
  overflow: hidden;
  background-color: transparent;
}

.option a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;

}
  ul li:hover ul li {
	  display:block;

	  }
	 body {
	
	background-image:url("yes2.jpg");
	background-repeat:none;
	background-size:cover;
	}



.option a.hover {
  background-color: gray;
  color: white;
   
}
.option a:hover {
  background-color: grey;
  color: red;
 
}
</style>
	
</head>
	
<?php
$bookingid=$_POST['bookingid'];
mysql_connect('localhost','root','') or die ('connection failed');
mysql_select_db('Nkhere_dba') or die ('database is not selected');

$sql="DELETE FROM booking WHERE bookingid='$bookingid'";
mysql_query($sql) or die ('bookings are not deleted');

echo 'bookings are successfully deleted';

?>
<body>
 <div class="option">
  <a href="ClientOptions.html"><font color="white"><strong> Back page </strong></font></a>
  </div>
</body>
</html>
