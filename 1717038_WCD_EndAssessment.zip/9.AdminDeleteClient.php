<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Nkhere_dba";
$Phone=$_POST['phone'];

// Creating new connection
 $conn =new mysqli($servername, $username, $password, $dbname);
// Checking a connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
// deleting a record
$delete = "DELETE FROM Client WHERE  phone='$Phone'";
if ($conn->query($delete) === TRUE) {
   echo '<script language="javascript">';
	echo 'alert("client is successfully blocked")';
    echo'</script>';
   
} else {
echo "Client is not blocked: " . $conn->error;
}
// closing the connection
$conn->close();
?>