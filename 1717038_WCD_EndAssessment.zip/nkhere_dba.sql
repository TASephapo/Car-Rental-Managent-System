-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2019 at 08:21 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nkhere_dba`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(20) NOT NULL,
  `Password4` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `Password4`) VALUES
('chef2@gmail.com', '111'),
('chef@gmail.com', '123'),
('dan2@gmail.com', '123'),
('dan@gmail.com', '123'),
('kantoro1@gmail.com', '123'),
('kantoro@gmail.com', '111'),
('kao@gmail.com', '123'),
('mookho@gmail.com', '123'),
('thulo@gmail.com', '123'),
('timello', '123'),
('tsepo5@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingid` int(11) NOT NULL,
  `Registrationnumber` int(11) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `surname` varchar(20) DEFAULT NULL,
  `driver` varchar(20) DEFAULT NULL,
  `Area` varchar(20) DEFAULT NULL,
  `destination` varchar(20) NOT NULL,
  `Date1` date DEFAULT NULL,
  `Time1` time DEFAULT NULL,
  `Price` int(11) NOT NULL,
  `message` text,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingid`, `Registrationnumber`, `Phone`, `Name`, `surname`, `driver`, `Area`, `destination`, `Date1`, `Time1`, `Price`, `message`, `status`) VALUES
(22222, 45, '56655', 'oooooooo', 'kkkkk', 'Teboho', 'Lithabaneng', 'Naleli', '2019-05-27', '05:05:00', 75, '', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `email` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password2` varchar(20) NOT NULL,
  `Confirm` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`email`, `phone`, `password2`, `Confirm`) VALUES
('ta.sephapo@bothouniv', '56655', '123', '123'),
('tau.sephapo@bothouni', '6777888', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `name` varchar(40) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Registrationnumber` int(11) NOT NULL,
  `DriverLicense` varchar(20) NOT NULL,
  `Picture` blob NOT NULL,
  `Reviews` varchar(20) NOT NULL,
  `Ratings` varchar(20) NOT NULL,
  `password1` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`name`, `Email`, `Registrationnumber`, `DriverLicense`, `Picture`, `Reviews`, `Ratings`, `password1`) VALUES
('thabo', 'thabo@gmail.com', 45, 'GHHH', 0x4d6f6c657473616e652e6a7067, 'okay', '*******', '123'),
('man', 'man@gmail.com', 459, 'FFI', 0x4d6f7461756e672e6a7067, 'OKAY', '****', '123');

-- --------------------------------------------------------

--
-- Table structure for table `drivermessage`
--

CREATE TABLE `drivermessage` (
  `email` varchar(20) NOT NULL,
  `Registrationnumber` int(11) DEFAULT NULL,
  `message` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messageclient`
--

CREATE TABLE `messageclient` (
  `Carrier` varchar(30) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `message` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messageclient`
--

INSERT INTO `messageclient` (`Carrier`, `phone`, `message`) VALUES
('Thabo', '56655', 'its fine');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `Registrationnumber` int(11) DEFAULT NULL,
  `Model` varchar(20) DEFAULT NULL,
  `CarMake` varchar(30) NOT NULL,
  `Passengers` int(11) DEFAULT NULL,
  `VINnumber` varchar(20) NOT NULL,
  `color` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`Registrationnumber`, `Model`, `CarMake`, `Passengers`, `VINnumber`, `color`) VALUES
(459, 'Prius+', 'Toyota', 444, '455', 'GREEN'),
(45, 'Prius+', 'Toyota', 12, '7877', 'Blue');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingid`),
  ADD KEY `fk_phone` (`Phone`),
  ADD KEY `Registrationnumber` (`Registrationnumber`,`Phone`) USING BTREE;

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`phone`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`Registrationnumber`);

--
-- Indexes for table `drivermessage`
--
ALTER TABLE `drivermessage`
  ADD PRIMARY KEY (`email`),
  ADD KEY `fk_regno1` (`Registrationnumber`);

--
-- Indexes for table `messageclient`
--
ALTER TABLE `messageclient`
  ADD PRIMARY KEY (`Carrier`),
  ADD KEY `fk_phone2` (`phone`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`VINnumber`),
  ADD KEY `fk_registrationnumber` (`Registrationnumber`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `fk_phone` FOREIGN KEY (`Phone`) REFERENCES `client` (`phone`),
  ADD CONSTRAINT `fk_registration` FOREIGN KEY (`Registrationnumber`) REFERENCES `driver` (`Registrationnumber`),
  ADD CONSTRAINT `fk_regno` FOREIGN KEY (`Registrationnumber`) REFERENCES `driver` (`Registrationnumber`);

--
-- Constraints for table `drivermessage`
--
ALTER TABLE `drivermessage`
  ADD CONSTRAINT `fk_regno1` FOREIGN KEY (`Registrationnumber`) REFERENCES `driver` (`Registrationnumber`);

--
-- Constraints for table `messageclient`
--
ALTER TABLE `messageclient`
  ADD CONSTRAINT `fk_phone2` FOREIGN KEY (`phone`) REFERENCES `client` (`phone`);

--
-- Constraints for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `fk_registrationnumber` FOREIGN KEY (`Registrationnumber`) REFERENCES `driver` (`Registrationnumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
