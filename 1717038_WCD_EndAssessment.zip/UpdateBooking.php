<?php
$bookingid=$_POST['bookingid'];
$bookingstatus=$_POST['status'];

mysql_connect('localhost','root','') or die ('connection failed');
mysql_select_db('Nkhere_dba') or die ('database is not selected');

$booking="Update booking set status='$bookingstatus' where bookingid='$bookingid'";

mysql_query($booking) or die ('booking status failed to update');

echo "Now booking status is" .$bookingstatus."<br>";

?>
<html>
 <head><title>BACK TO HOMEPAGE </title>
    <style type="text/css">
   
   body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.option{
  overflow: hidden;
  background-color: transparent;
}

.option a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;

}
  ul li:hover ul li {
	  display:block;

	  }
	 body {
	
	background-image:url("yes2.jpg");
	background-repeat:none;
	background-size:cover;
	}



.option a.hover {
  background-color: gray;
  color: white;
   
}
.option a:hover {
  background-color: grey;
  color: red;
 
}
</style>
</head>
  <body>
 <div class="option">
  <a href="driveroptions.html"><font color="white"><strong> Back page </strong></font></a>
  </div>
</body>
</html>