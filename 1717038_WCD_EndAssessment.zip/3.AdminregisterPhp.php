<?php

  $email=$_POST['email'];
  $Password=$_POST['Password4'];
  
  
   mysql_connect('localhost','root','') or die ('connection failed');
   mysql_select_db('Nkhere_dba') or die ('database not selected');
   $query="insert into Admin values ('".$email."','".$Password."')";
   mysql_query($query) or die ('data is not inserted');
	
    echo '<script language="javascript">';
	echo 'alert("successfully registered please login")';
    echo'</script>';
   
?>

<html>
<head><title>ADMIN LOG IN </title>
<style>

body {
	
	background-image:url("yes2.jpg");
	background-repeat:none;
	background-size:cover;
	}

</style>
</head>
<body>
<h1> CLICK BELOW OPTION TO LOG IN </h1><br>
<a href="4.Adminsession.php"><font color="white" size="20"><strong>Login </strong> </font></a> 
</body>

</html>
   
   