<html>
  
  <head><title> CLIENT VIEW BOOKINGS </title></head>
  <div align="center">
  <h1> BOOKINGS STATUS</h1>
  <table border="1" cellpadding="5" cellspacing="6">
   <tr>
     <th>bookingid </th>
     <th>Registrationnumber</th>
      <th>phone=  </th>
       <th>Name </th>
        <th>surname </th>
         <th>driver</th>
         <th>Area</th>
     <th>destination</th>
         <th>Date </th>
      <th>Time </th>
     <th>Price </th>
	 <th>message</th>
	 <th>status </th>
	 </tr>
   
  
  	<?php
     
	 
	mysql_connect('localhost','root','') or die ('connection failed');
    mysql_select_db('Nkhere_dba') or die ('database is not selected');
    $run3=mysql_query("select bookingid,Registrationnumber,phone,Name,surname,driver,Area,destination,Date1,Time1,
                       price,message,status	from booking");
	
	
	 while( $row=(mysql_fetch_array($run3)))
	{
	  
     
	 
	
     $bookingid=$row[0];
     $Registrationnumber=$row[1];
     $phone=$row[2];
     $Name=$row[3];
     $surname=$row[4];
     $driver=$row[5];
     $Area=$row[6];
     $destination=$row[7];
     $Date1=$row[8];
     $Time1=$row[9];
     $Price=$row[10];
	 $message=$row[11];
	 $bookingstatus=$row[12];
   
  
  
	
	
	    echo  "<tr>
		          <td>$bookingid</td>
		         <td>$Registrationnumber</td>
				 <td>$phone</td> 
	            <td>$Name </td>
				<td> $surname</td>
				<td> $driver</td>
				<td> $Area </td>
				<td> $destination </td>
				<td> $Date1</td>
				<td> $Time1 </td>
				<td> $Price </td>
				<td> $message</td>
				<td>$bookingstatus</td>
				
				
		 <tr>";
				
	}
	
	
?>
</table>
</div>
<body>
 <div class="option">
  <a href="ClientOptions.html"><font color="white"><strong> Back page </strong></font></a>
  </div>
</body>
</html>