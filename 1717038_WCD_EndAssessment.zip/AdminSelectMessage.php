<html>
  <head><title> Admin See Messages </title></head>
  
  <body>
  <h1> Messages from Clients </h1>
  <table border="1">
    <tr>
	 <th></strong>Carrier </strong></th>
      <th><strong>Phone </strong> </th>
        <th><strong>Message</strong></th>
		</tr>
		
		<?php
     
	 
	mysql_connect('localhost','root','') or die ('connection failed');
    mysql_select_db('Nkhere_dba') or die ('database is not selected');
    $run=mysql_query("select * from messageclient");
    
	
 
   while( $row=(mysql_fetch_array($run)))
   {
	   
	 $Carrier=$row[0];
     $phone=$row[1];
     $message=$row[2];
    
	echo "<tr>
	          <td>$Carrier</td>
			  <td>$phone </td>
			  <td>$message</td>
			 
			 </tr>";
	   
	   
  }
	   
?>
</table>
</div>

 
</html>
	
  
  
  
  
   </body>
   
   </html>