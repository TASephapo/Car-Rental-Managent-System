<?php
 
  $bookingid=$_POST['bookingid'];
  $Registrationnumber=$_POST['Registrationnumber'];
  $phone=$_POST['phone'];
  $Name=$_POST['Name'];
  $surname=$_POST['surname'];
  $driver=$_POST['driver'];
  $Area=$_POST['Area'];
  $destination=$_POST['destination'];
  $Date1=$_POST['Date1'];
  $Time1=$_POST['Time1'];
  $Price=$_POST['Price'];
  $message=$_POST['message'];
   

  mysql_connect('localhost','root','') or die ('connection failed');
  mysql_select_db('Nkhere_dba') or die ('database is not selected');
  
  $Query = "insert into booking values ('".$bookingid."','".$Registrationnumber."','".$phone."', '".$Name."','".$surname."','".$driver."','".$Area."',
  '".$destination."','".$Date1."', '".$Time1."','".$Price."','".$message."')";
  
  mysql_query($Query) or die ('data is not inserted');
  
         echo '<script language="javascript">';
	     echo 'alert("You have successfully booked click ok to view bookings ")';
         echo'</script>';
?>
<html>
<head><title>ADMIN LOG IN </title>
<style>

body {
	
	background-image:url("yes2.jpg");
	background-repeat:none;
	background-size:cover;
	}

</style>
</head>
<body>
<h1> CLICK BELOW OPTION TO BOOK </h1><br>
<a href="DriverViewClients.php"><font color="white" size="20"><strong>VIEW BOOKINGS </strong> </font></a> 
</body>

</html>
 
 