 <?php
	$connection=mysqli_connect('localhost','root','','Nkhere_dba');
	
	if($connection->connect_error)
	{
		die ('failed to connect'.$connection->connect_error);
	}
	
?>
	<html>
	
		<head><title> DRIVER'S SESSION </title>
		<link rel="stylesheet" type="text/css" href="cssLoginsdriver.css">
		</head>
	 <body style="background-color:#003b3b;">
	 
	 
	 <form id="input"  action="" method="POST" > 
	  <table align="center">
	  <h1 align="center">PLEASE LOGIN </h1>
	  <tr>
	     <td> <strong>Car Registration number </strong>
				
		<td><input type="number" name="Registrationnumber" size="30" placeholder="Car Registration number" ></td></tr><br>
		
		<tr>
			<td><strong>Enter Password </strong>
			<td><input type="Password"  name="Password1" Placeholder="Enter Password " ></td></tr><br>
			<tr>
				<td><input type="submit" value="LOGIN" 	name="submit" ></td></tr>
				<tr><td align="center" colspan="5"> <p color="white"> <font size="15"> Not  Registered Yet? <br> click 
                </font> <a href="2.Admin register.html"> Register </p> </a> </br></td></tr>
				
			</table>
			</form>
			
			
		<?php
		 
		  session_start();
		if ( isset($_POST["submit"]))
		{
			$Registrationnumber=$_POST["Registrationnumber"];
			$Password=$_POST["Password1"];
			$Query=("select * from driver where Registrationnumber='$Registrationnumber' && Password1='$Password'");
		    $Query= mysqli_query($connection,$Query);
			$login=mysqli_num_rows($Query);
			
			if($login==1)
			{
				//starting a session 
				
				$_session['Registrationnumber']=$Registrationnumber;
				echo "successfully logged in";
				header('location:driveroptions.html'); 
				
			}
			else
			{
				 echo "Failed to login";
				 
				 
			}
		}
				
		?>
   
	
	</html>