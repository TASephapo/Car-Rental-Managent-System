<html>
   <head><title>SELECTING FROM DRIVER </title>
   <style type="text/css">
   
   body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.option{
  overflow: hidden;
  background-color: transparent;
}

.option a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;

}
  ul li:hover ul li {
	  display:block;

	  }
	 body {
	
	background-image:url("yes2.jpg");
	background-repeat:none;
	background-size:cover;
	}



.option a.hover {
  background-color: gray;
  color: white;
   
}
.option a:hover {
  background-color: grey;
  color: red;
 
}
</style>
   
   </head>
    
	 <div align="center">
    <h1> BOOKINGS </h1> 
	 <table border="1" width="100" cellpadding="5" cellspacing="6">
	 <tr>
	 <th>Booking Id </th>
	 <th>Registrationnumber</th>
	 <th> Phone </th>
	 <th> Name </th>
	 <th>Surname </th>
	 <th> driver</th>
	 <th>Area </th>
	 <th>destination</th>
	  <th>Date1</th>
	  <th>Time1</th>
	  <th>Price </th>
	  <th>Message </th>
	  
	 
	 </tr>
	 
	 <?php
	 
	
     mysql_connect('localhost','root','') or die ('connection failed');
     mysql_select_db('Nkhere_dba') or die ('database is not selected');
	$run=mysql_query(" select * from booking");
	
	while( $row=(mysql_fetch_array($run)))
	{
	 $bookingid=$row[0];
     $Registrationnumber=$row[1];
     $phone=$row[2];
     $Name=$row[3];
     $surname=$row[4];
     $driver=$row[5];
     $Area=$row[6];
     $destination=$row[7];
     $Date1=$row[8];
     $Time1=$row[9];
     $Price=$row[10];
     $message=$row[11];
	 
	
	
		
		
		echo "<tr> 
		      <td> $bookingid </td>
		      <td> $Registrationnumber</td>
              <td> $phone </td>
               <td> $Name</td> 
               <td> $surname </td>
               <td> $driver </td>
                <td>  $Area  </td>
                <td>$destination </td>
                <td> $Date1</td>
                <td>$Time1 </td>
                 <td>$Price  </td>
                    <td>$message</td>
				
				</tr>";
				
	}
?>
</table>

</div>
<body>
 <div class="option">
  <a href="driveroptions.html"><font color="white"><strong> Back page </strong></font></a>
  </div>
</body>

</html>