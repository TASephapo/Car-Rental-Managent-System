<html>
	<head><title> THIS IS A PHP FILE FOR A DRIVER </title></head>

<?php
	
	$name=$_POST["name"];
	$Email=$_POST["Email"];
	$Registrationnumber=$_POST["Registrationnumber"];
	$DriverLicense=$_POST["DriverLicense"];
	$CarMake=$_POST["CarMake"];
	$model=$_POST["model"];
	$Passengers=$_POST["Passengers"];
	$VINnumber=$_POST["VINnumber"];
	$Picture=$_POST['Picture'];
	$Reviews=$_POST['Reviews'];
	$Ratings=$_POST['Ratings'];
	$color=$_POST["color"];
	$Password=$_POST["Password1"];
	
		mysql_connect('localhost','root','') or die ('connection failed');
		mysql_select_db('nkhere_dba') or die ('database is not selected');
	
		$Query="insert into driver values ('".$name."','".$Email."','".$Registrationnumber."','".$DriverLicense."',
		'".$Picture."','".$Reviews."','".$Ratings."','".$Password."')";
		
		$Query1="insert into vehicles values ('".$Registrationnumber."','".$model."','".$CarMake."','".$Passengers."','".$VINnumber."',
		'".$color."')";
		
		mysql_query($Query) or die ('data is not inserted into driver table');
		
		mysql_query($Query1) or die ('data is not inserted into vehicles');
		 
		 echo "data is successfully inserted";
		 
?>
</html>		
	
	
	