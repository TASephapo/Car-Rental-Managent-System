<?php
	$connection=mysqli_connect('localhost','root','','Nkhere_dba');
	
	if($connection->connect_error)
	{
		die ('failed to connect'.$connection->connect_error);
	}
	
?>

<html>
	
		<head><title> CLIENTS SESSION </title>
		<link rel="stylesheet" type="text/css" href="14.Clientlogincss.css">
		</head>
	 <body style="background-color:#003b3b;">
	 
	 
	 <form id="input"  action="" method="POST" > 
	  <table align="center">
	  <h1 align="center">PLEASE LOGIN </h1>
	  <tr>
	     <td> <strong>Phone Number </strong>
				
		<td><input type="text" name="phone" size="30" placeholder="Phone number" ></td></tr><br>
		
		<tr>
			<td><strong>Enter Password </strong>
			<td><input type="Password"  name="password2" Placeholder="Enter Password " ></td></tr><br>
			<tr><td></td></tr>
			<tr>
				<td colspan="3" align="center"><input type="submit" value="LOGIN" 	name="submit"></td></tr>
				
				<tr><td align="center" colspan="5"> <p color="white"> <font size="10">Not Registered Yet? <br> click 
				</font> <a href="10.ClientRegister.html"> <b> Register </b> </p> </a> </br></td></tr>
				
			</table>
			</form>
			
			
		<?php
		
		if ( isset($_POST["submit"]))
		{
			$Phone=$_POST["phone"];
			$Password=$_POST["password2"];
			$Query=("select * from client where phone='$Phone' && password2='$Password'");
		    $Query= mysqli_query($connection,$Query);
			$login=mysqli_num_rows($Query);
			
			if($login==1)
			{
				//starting a session 
				
				$_session['phone']=$Phone;
				header('location:ClientOptions.html'); 
				echo "successfully logged in";
				echo '<script language="javascript">';
	            echo 'alert("successfully logged in")';
               echo'</script>';
				
			
				
			}
			else
			{
				 
		      echo '<script language="javascript">';
	          echo 'alert("failed to login please try again")';
               echo'</script>';
				 
				 
			}
		}
				
		?>
		
		
		</html>
			