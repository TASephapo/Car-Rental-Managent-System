<?php
$Carrier=$_POST['Carrier'];
$phone=$_POST["phone"];
$message=$_POST['message'];

	
		mysql_connect('localhost','root','') or die ('connection failed');
		mysql_select_db('nkhere_dba') or die ('database is not selected');
	
		$Query="insert into messageclient values ('".$Carrier."','".$phone."','".$message."')";
		
		mysql_query($Query) or die ('data is not inserted');
		 
		 echo "data is successfully inserted";
?>
		 
