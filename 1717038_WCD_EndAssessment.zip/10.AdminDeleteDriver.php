<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Nkhere_dba";
$Registrationnumber=$_POST["Registrationnumber"];

// Creating new connection
 
 $conn=new mysqli($servername, $username, $password, $dbname);
 
// Checking a connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
// deleting a record
$delete1="DELETE FROM vehicles WHERE Registrationnumber='$Registrationnumber'";
$delete = "DELETE FROM driver WHERE Registrationnumber ='$Registrationnumber'";
if ($conn->query($delete1)=== TRUE)  
{
  if ($conn->query($delete) === TRUE) {
    echo "Driver  successfully blocked";
} 
}else {
echo "Driver is not blocked:" . $conn->error;
}
// closing the connection
$conn->close();
?>