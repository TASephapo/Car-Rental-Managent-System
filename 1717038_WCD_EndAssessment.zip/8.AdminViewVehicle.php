<html>
 <div align="center">
    <h1> CAR DETAILS </h1>
    <table border="1" width="200">
   
   <tr>
    
	 <th>Registrationnumber</th>
     <th> Car Model</th>
	 <th> car make </th>
	 <th> Number of passengers </th>
	 <th>  VINnumber </th>
	 <th>Color</th>
	 </tr>
	 
	<?php
     
	 
	mysql_connect('localhost','root','') or die ('connection failed');
    mysql_select_db('Nkhere_dba') or die ('database is not selected');
    $run3=mysql_query("select * from vehicles");
	
	
	 while( $row=(mysql_fetch_array($run3)))
	{
	   $Registrationnumber=$row[0];
	   $model=$row[1];
	   $CarMake=$row[2];
	   $Passengers=$row[3];
	   $VINnumber=$row[4];
	   $color=$row[5];
	
	
	    echo  "<tr>
		         <td>$Registrationnumber</td>
				 <td> $model</td> 
	            <td>$CarMake </td>
				<td> $Passengers</td>
				<td> $VINnumber</td>
				<td> $color </td>
		 <tr>";
				
	}
?>
</table>
</div>
</html>