<html>
  <head><title> Driver See Messages </title></head>
  
  <body>
  <h1> Messages to clients </h1>
  <table border="1" cellpadding="5" cellspacing="6">
    <tr>
	 <th></strong>Email </strong></th>
      <th><strong>Registration number </strong> </th>
        <th><strong>Message</strong></th>
		</tr>
		
		<?php
     
	 
	mysql_connect('localhost','root','') or die ('connection failed');
    mysql_select_db('Nkhere_dba') or die ('database is not selected');
    $run=mysql_query("select * from drivermessage");
    
	
 
   while( $row=(mysql_fetch_array($run)))
   {
	   
	 $email=$row[0];
     $Registrationnumber=$row[1];
     $message=$row[2];
    
	echo "<tr>
	          <td>$email</td>
			  <td>$Registrationnumber </td>
			  <td>$message</td>
			 
			 </tr>";
	   
	   
  }
	   
?>
</table>
</div>

 
</html>