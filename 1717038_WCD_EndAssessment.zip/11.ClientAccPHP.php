<?php
	
	$email=$_POST["email"];
	$phone=$_POST["phone"];
	$password=$_POST["password2"];
	$Confirm=$_POST["Confirm"];
	
	
		mysql_connect('localhost','root','') or die ('connection failed');
		mysql_select_db('nkhere_dba') or die ('database is not selected');
	
		$Query="insert into client values ('".$email."','".$phone."','".$password."','".$Confirm."')";
		
		mysql_query($Query) or die ('data is not inserted');
		 
		  echo '<script language="javascript">';
	      echo 'alert("successfully registered please login ")';
          echo'</script>';
		 
		 
		?>
<html>
	<head><title> THIS IS A PHP FILE FOR A DRIVER </title></head>
		<body bgcolor="blue">
		
		<p align="center"><b>successfully registered now<br> click</b>
		<a href="12.sessionClient.php"><strong> LOGIN </strong></a>
		</body>
		
</html>		