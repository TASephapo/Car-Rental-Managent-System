<?php

session_start();
session_unset();

header ('location:4.Adminsession.php');


?>